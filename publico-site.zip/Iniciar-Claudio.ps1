$ErrorActionPreference = 'Stop'
$appName = 'ClaudioSeguro'
$packageDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$configPath = Join-Path $packageDir 'config.json'
$userDir = Join-Path $env:LOCALAPPDATA $appName
$credentialPath = Join-Path $userDir 'credencial.xml'

if (-not (Test-Path -LiteralPath $configPath)) { throw 'config.json nao encontrado.' }
$config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
$familyMode = [bool]$config.family_mode
$serverUrl = [string]$config.server_url
if ([string]::IsNullOrWhiteSpace($serverUrl) -or $serverUrl -like '*SEU-DOMINIO-AQUI*') {
    $serverUrl = Read-Host 'Endereco HTTPS do servidor Claudio'
}
$serverUrl = $serverUrl.TrimEnd('/')
if ($serverUrl -notmatch '^https://' -and $serverUrl -notmatch '^http://(127\.0\.0\.1|localhost)(:\d+)?$') {
    throw 'Por seguranca, use HTTPS. HTTP so e aceito em localhost.'
}

New-Item -ItemType Directory -Path $userDir -Force | Out-Null
if (Test-Path -LiteralPath $credentialPath) {
    $credential = Import-Clixml -LiteralPath $credentialPath
} else {
    $licenseId = [string]$config.license_id
    if ([string]::IsNullOrWhiteSpace($licenseId)) { $licenseId = Read-Host 'Chave da licenca' }
    $securePassword = Read-Host 'Senha da licenca' -AsSecureString
    $credential = [PSCredential]::new($licenseId, $securePassword)
    $credential | Export-Clixml -LiteralPath $credentialPath
}

$plainPassword = $credential.GetNetworkCredential().Password
$combinedToken = '{0}:{1}' -f $credential.UserName, $plainPassword
$headers = @{ Authorization = "Bearer $combinedToken" }
try {
    $status = Invoke-RestMethod -Uri "$serverUrl/api/auth/test" -Headers $headers -Method Get -TimeoutSec 20
    if (-not $status.ok) { throw 'Autenticacao recusada.' }
} catch {
    throw "Falha de conexao ou autenticacao: $($_.Exception.Message)"
}

$used = [double]$status.total_tokens
$limit = [double]$status.limite_tokens
$percent = if ($limit -gt 0) { [Math]::Min(100, [Math]::Round(($used / $limit) * 100, 1)) } else { 0 }
$mascot = @'
       /\_/\\
  ____/ o o \____
 /  _    ^    _  \
|  / \  BAD  / \  |
 \_\  CLAUDIO  /_/
    \_________/
'@
Write-Host $mascot -ForegroundColor Red

$missionPath = Join-Path $packageDir 'missoes.json'
$missionData = Get-Content -LiteralPath $missionPath -Raw -Encoding UTF8 | ConvertFrom-Json
$phrases = if ($familyMode) { @($missionData.girias.familia) } else { @($missionData.girias.normal) }
$phraseIndex = [Math]::Abs(([int]$status.total_requisicoes + [DateTime]::Now.DayOfYear)) % $phrases.Count
Write-Host ('Mascote: ' + $phrases[$phraseIndex]) -ForegroundColor Magenta
Write-Host ("Uso do plano: {0:N0} / {1:N0} tokens ({2}%)" -f $used, $limit, $percent) -ForegroundColor Cyan
$unlocked = @($missionData.camadas | Where-Object { $used -ge [double]$_.tokens } | Select-Object -Last 1)
$nextMission = @($missionData.camadas | Where-Object { $used -lt [double]$_.tokens } | Select-Object -First 1)
if ($unlocked.Count -gt 0) { Write-Host ("Camada atual: " + $unlocked[0].nome) -ForegroundColor Green }
if ($nextMission.Count -gt 0) { Write-Host ("Proxima missao: " + $nextMission[0].missao + " (" + ('{0:N0}' -f [double]$nextMission[0].tokens) + " tokens)") -ForegroundColor Yellow }

$env:ANTHROPIC_BASE_URL = $serverUrl
$env:ANTHROPIC_AUTH_TOKEN = $combinedToken
$env:ANTHROPIC_API_KEY = $combinedToken
Write-Host "Conexao segura validada para $($status.cliente)." -ForegroundColor Green

Write-Host ''
Write-Host 'ESCOLHA COMO USAR O BADCLAUDIO' -ForegroundColor Red
Write-Host '[1] BadClaudio Power  - programacao no terminal + skills Claude instaladas'
Write-Host '[2] Interface Normal  - chat visual no navegador'
$launchMode = Read-Host 'Opcao [1-2] (padrao: 1)'
if ([string]::IsNullOrWhiteSpace($launchMode)) { $launchMode = '1' }

if ($launchMode -eq '2') {
    $normalUrl = [string]$config.normal_interface_url
    if ([string]::IsNullOrWhiteSpace($normalUrl) -or $normalUrl -like '*SEU-DOMINIO-AQUI*') {
        $localInterface = Join-Path $packageDir 'Interface-Normal.html'
        Start-Process $localInterface
        Write-Host 'Interface Normal local aberta. A IA online sera ativada pelo endereco HTTPS do administrador.' -ForegroundColor Yellow
        exit 0
    }
    if ($normalUrl -notmatch '^https://') { throw 'A Interface Normal precisa usar HTTPS.' }
    Start-Process $normalUrl
    Write-Host 'Interface Normal aberta no navegador.' -ForegroundColor Green
    exit 0
}
if ($launchMode -ne '1') { throw 'Opcao invalida. Escolha 1 ou 2.' }

$claudeSkillsDir = Join-Path $env:USERPROFILE '.claude\skills'
$skillCount = 0
if (Test-Path -LiteralPath $claudeSkillsDir) {
    $skillCount = @(Get-ChildItem -LiteralPath $claudeSkillsDir -Directory -ErrorAction SilentlyContinue).Count
}
Write-Host ("BadClaudio Power: {0} skill(s) Claude instalada(s) detectada(s)." -f $skillCount) -ForegroundColor Cyan
Write-Host 'Somente skills presentes e autorizadas neste computador serao usadas.' -ForegroundColor DarkGray

$claude = Get-Command claude -ErrorAction SilentlyContinue
if (-not $claude) {
    Write-Host 'Claude Code nao esta instalado. Execute Instalar-Dependencias.bat como usuario normal.' -ForegroundColor Yellow
    exit 2
}
& $claude.Source

