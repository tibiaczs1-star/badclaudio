@echo off
setlocal
title BadClaudio - Iniciar
cd /d "%~dp0"
node -v >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo Node.js nao encontrado. Baixe em https://nodejs.org e instale.
    pause
    exit /b 1
)
echo ==========================================================
echo   BADCLAUDIO - escolha sua interface (CLI em shell)
echo ==========================================================
echo [1] Interface Normal  - mascote, missões, histórico local
echo [2] Interface Clean   - minimalista, direto ao ponto
echo [3] Agent Room 2D     - escritório pixel art no navegador
set /p MODO="Opcao [1-3] (padrao: 1): "
if "%MODO%"=="" set MODO=1
if "%MODO%"=="1" node claudio-cli-normal.mjs
if "%MODO%"=="2" node claudio-cli-clean.mjs
if "%MODO%"=="3" (
    start "" http://127.0.0.1:3399
    node agent-room\agente-room.mjs
)
pause
